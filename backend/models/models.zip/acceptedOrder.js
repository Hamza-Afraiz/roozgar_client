const mongoose = require('mongoose');

const accpetedOrderSchema = mongoose.Schema({
    serviceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'service',
        
        
    },
    clientId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'client',
        
    },
    vendorId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'vendor',
        
    },

    
    price:{
       type:String,
       default:'0'
    },
    completionTime:{
        type:String,
        default:'0'
    },
    dateCreated: {
        type: Date,
        default: Date.now,
    },
})

accpetedOrderSchema .virtual('id').get(function () {
    return this._id.toHexString();
});

accpetedOrderSchema.set('toJSON', {
    virtuals: true,
});


exports.AcceptedOrder = mongoose.model('accpetedOrder', accpetedOrderSchema );
